Diary App v0.1.0 — 日记本 Android App

文件:
  diary-debug-0.1.0.apk      Debug 包，带调试签名
  diary-release-0.1.0.apk    Release 包，V2 签名（debug keystore 演示用）

安装方法:
  adb install diary-release-0.1.0.apk
  # 或：手机打开 USB 调试，把 apk 拷进去点击安装

源码目录:/work/1/diary-app